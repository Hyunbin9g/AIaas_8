package com.myaddr.myapp.service;

import java.util.List;

import com.myaddr.myapp.model.AddrVO;

public interface IAddrService {
	 List<AddrVO> getAllContacts() ;
		public void insertAddr(AddrVO vo);
		public AddrVO searchAddr(String id);
		void updateAddr(AddrVO vo);
		void deleteAddr(String id);
}
