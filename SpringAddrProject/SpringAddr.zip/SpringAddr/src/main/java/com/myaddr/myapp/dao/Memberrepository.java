package com.myaddr.myapp.dao;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.myaddr.myapp.model.MemberVO;

@Repository
public class Memberrepository implements IMemberrepository {

	@Autowired
	MemberVO membervo;

	@Autowired
	JdbcTemplate jdbcTemplate;

	@Override
	public boolean checkLogin(String mid, String pwd) {
		String sql = "SELECT COUNT(*) FROM MEMBER WHERE mid=? AND pwd=?";
		int count = jdbcTemplate.queryForObject(sql, Integer.class, mid, pwd);
		return count > 0;
	}
	@Override
	public void addrMember(MemberVO vo) {
		String sql = "INSERT INTO MEMBER (id, name, email, mid, pwd, phone, address) VALUES (?, ?, ?, ?, ?, ?, ?)";
		jdbcTemplate.update(sql, vo.getId(),vo.getName(),vo.getEmail(),vo.getMid(),vo.getPwd(),vo.getPhone(),vo.getAddress());
	}

}
