package com.myaddr.myapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.myaddr.myapp.model.AddrVO;
import com.myaddr.myapp.service.IAddrService;

@Controller
public class addrController {

	@Autowired
	private IAddrService addrService;

	@GetMapping("/addr-main")
	public String getAdressBook(Model model) {
		List<AddrVO> addrList = addrService.getAllContacts();
		model.addAttribute("addrList", addrList);
		return "addr-main";

	}

	@GetMapping("/insert-addr")
	public String insertAddr() {
		return "addr-insert";
	}

	@PostMapping("/insert-addr")
	public String insertingAddr(Model model, AddrVO vo) {
		addrService.insertAddr(vo);
		return "redirect:/addr-main";
	}

//		@GetMapping("/user-update/${addr.id}")
//		public String updateAddr(@RequestParam("id") String id, Model model) {
//			model.addAttribute("addrVO",addrService.searchAddr(id));
//			return "AddrUpdate";
//		}			쿼리스트링과 pathvariable 연습
	@GetMapping("/user-update/{id}")
	public String updateAddr(@PathVariable String id, Model model) {
		model.addAttribute("addrVO", addrService.searchAddr(id));
		return "addr-update";
	}

	@GetMapping("/user-delete/{id}")
	public String deleteAddr(@PathVariable String id) {
		addrService.deleteAddr(id);

		return "redirect:/addr-main";
	}

	@PostMapping("/user-update")
	public String updatingAddr(AddrVO vo) {
		addrService.updateAddr(vo);
		return "redirect:/addr-main";
	}

}
