package com.myaddr.myapp.model;

import org.springframework.stereotype.Component;

import lombok.Data;
@Data
@Component
public class AddrVO {
	private int id;
	private String name;
    private String group_Name;
	private String phone_Number;
	private String email;
	private String address;
	private String memo;

}
