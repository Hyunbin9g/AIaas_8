function infoConfirm() {

	if (document.reg_frm.mid.value.length == 0) {
		alert("아이디는 필수사항입니다");
		
		reg_frm.mid.focus();
		return false;
	}

	if (document.reg_frm.mid.value.length < 4) {
		alert("아이디는 4글자 이상이어야 합니다");
		reg_frm.mid.focus();
		return false;
	}

	if (document.reg_frm.pwd.value.length == 0) {
		alert("비밀번호는 필수사항입니다");
		reg_frm.pwd.focus();
		return false;
	}

	if (document.reg_frm.pwd.value.length < 8) {
		alert("비밀번호는 8글자 이상이어야 합니다");
		reg_frm.pwd.focus();
		return false;
	}

	if (document.reg_frm.pwd.value != document.reg_frm.chpwd.value) {
		alert("비밀번호가 일치하지 않습니다.");
		reg_frm.pwd.focus();
		return false;
	}

	if (document.reg_frm.name.value.length == 0) {
		alert("이름은 필수사항입니다");
		reg_frm.name.focus();
		return false;
	}
	if (document.reg_frm.phone.value.length == 0) {
		alert("핸드폰 번호는 필수사항입니다");
		reg_frm.phone.focus();
		return false;
	}
	if (document.reg_frm.email.value.length == 0) {
		alert("메일은 필수사항입니다");
		reg_frm.email.focus();
		return false;
	}

	if (document.reg_frm.address.value.length == 0) {
		alert("주소는 필수사항입니다");
		reg_frm.address.focus();
		return false;
	}

}

function confirmSubmission() {
        return confirm("정말로 수정하시겠습니까?");
    }

 