document.addEventListener('DOMContentLoaded', function loadData() {
    fetch('/AddrMain')
        .then(response => response.json())
        .then(data => {
            renderAddressTable(data); // JSON 데이터를 이용하여 테이블 렌더링
        })
        .catch(error => {
            console.error('Error fetching data:', error);
        });
});

function renderAddressTable(addresses) {
    var tableHtml = '<table border="1">';
    tableHtml += '<thead>';
    tableHtml += '<tr>';
    tableHtml += '<th>Name</th>';
    tableHtml += '<th>Group</th>';
    tableHtml += '<th>Phone Number</th>';
    tableHtml += '<th>Email</th>';
    tableHtml += '<th>Address</th>';
    tableHtml += '<th>Memo</th>';
    tableHtml += '<th></th>';
    tableHtml += '</tr>';
    tableHtml += '</thead>';
    tableHtml += '<tbody>';

    addresses.forEach(function(addr) {
        tableHtml += '<tr>';
        tableHtml += '<td>' + addr.name + '</td>';
        tableHtml += '<td>' + addr.group_Name + '</td>';
        tableHtml += '<td>' + addr.phone_Number + '</td>';
        tableHtml += '<td>' + addr.email + '</td>';
        tableHtml += '<td>' + addr.address + '</td>';
        tableHtml += '<td>' + addr.memo + '</td>';
        tableHtml += '<td>';
        tableHtml += '<a href="/user-update/' + addr.id + '">보기</a>';
        tableHtml += '</td>';
        tableHtml += '</tr>';
    });

    tableHtml += '</tbody>';
    tableHtml += '</table>';

    // 주소록 테이블을 HTML 요소에 추가
    document.getElementById('addressTable').innerHTML = tableHtml;
}
