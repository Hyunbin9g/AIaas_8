package com.myaddr.myapp.service;

import com.myaddr.myapp.model.MemberVO;

public interface IMemberService {
	boolean login(String mid,String pwd);
	void addrMembers(MemberVO vo);
}
