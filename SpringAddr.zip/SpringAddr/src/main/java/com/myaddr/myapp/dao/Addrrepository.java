package com.myaddr.myapp.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.myaddr.myapp.model.AddrVO;

@Repository
public class Addrrepository implements IAddrrepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public List<AddrVO> getAllContacts() {

		String sql = "select * from addrmember";
		return jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(AddrVO.class));
	}

	public void addMember(AddrVO vo) {
		String sql = "INSERT INTO ADDRMEMBER (name, group_name, phone_number, email, address, memo) VALUES (?, ?, ?, ?, ?, ?)";
		jdbcTemplate.update(sql, vo.getName(), vo.getGroup_Name(), vo.getPhone_Number(), vo.getEmail(), vo.getAddress(),
				vo.getMemo());
	}

	public AddrVO callId(String id) {
		String sql = "select * from addrmember where id=?";
		try {
			return jdbcTemplate.queryForObject(sql, new Object[] { id }, new BeanPropertyRowMapper<>(AddrVO.class));
		} catch (Exception e) {
			return null;
		}
	}
	public void updateMember(AddrVO vo) {
	    String sql = "UPDATE ADDRMEMBER SET name = ?, group_name = ?, phone_number = ?, email = ?, address = ?, memo = ? WHERE id = ?";
	    jdbcTemplate.update(sql, vo.getName(), vo.getGroup_Name(), vo.getPhone_Number(), vo.getEmail(), vo.getAddress(), vo.getMemo(), vo.getId());
	}
	public void deleteMember(int id) {
		String sql="DELETE FROM addrmember WHERE id = ?";
		jdbcTemplate.update(sql, id);
				
	}

	
}
