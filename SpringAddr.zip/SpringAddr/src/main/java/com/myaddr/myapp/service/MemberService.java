package com.myaddr.myapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.myaddr.myapp.dao.IMemberrepository;
import com.myaddr.myapp.model.MemberVO;

@Service("memberService")
public class MemberService implements IMemberService{

	
	@Autowired
	IMemberrepository memberrepository;
	
	@Override
	public boolean login(String mid,String pwd) {
		return memberrepository.checkLogin(mid,pwd);
	}
	
	@Override
	public void addrMembers(MemberVO vo){
		memberrepository.addrMember(vo);
	}
	
	
}
