package com.myaddr.myapp.dao;


import com.myaddr.myapp.model.MemberVO;

public interface IMemberrepository {
	
	boolean checkLogin(String mid, String pwd);
	void addrMember(MemberVO vo);
	
}
