package com.myaddr.myapp.dao;

import java.util.List;

import com.myaddr.myapp.model.AddrVO;

public interface IAddrrepository {
	List<AddrVO> getAllContacts();
	void addMember(AddrVO vo);
	AddrVO callId(String id);
	void updateMember(AddrVO vo);
	void deleteMember(int id);
}
