package com.myaddr.myapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.myaddr.myapp.dao.IAddrrepository;
import com.myaddr.myapp.model.AddrVO;

@Service("addrService")
public class AddrService implements IAddrService {

	@Autowired
	IAddrrepository addrrepository;

	public List<AddrVO> getAllContacts() {
		
		return addrrepository.getAllContacts();
		
	}
	public AddrVO searchAddr(String id) {
		return addrrepository.callId(id);
	}

	public void insertAddr(AddrVO vo) {
		addrrepository.addMember(vo);
	}
	
	public void updateAddr(AddrVO vo) {
		addrrepository.updateMember(vo);
	}
	
	public void deleteAddr(String id) {
		int num = Integer.parseInt(id);	
		addrrepository.deleteMember(num);
	}
	
	
}
