
package com.myaddr.myapp.controller;

import java.util.Locale;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.myaddr.myapp.model.MemberVO;
import com.myaddr.myapp.service.IMemberService;

@Controller
public class memberController {

	@Autowired
	private IMemberService memberService;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale) {
		return "index";
	}

	@PostMapping(value={"/loging","/myapp/loging"})
	public String loginHome(@RequestParam("mid") String memberId, @RequestParam("pwd") String password,
			HttpSession session, RedirectAttributes redirectAttributes) {

		boolean loggedIn = memberService.login(memberId, password);

		if (loggedIn) {
			session.setAttribute("mid", memberId);
			return "redirect:/";
		} else {
			redirectAttributes.addFlashAttribute("error", "다시 로그인시도 하십시오.");
			return "redirect:myapp/user-login";
		}
	}

	@RequestMapping(value = "/user-register", method = RequestMethod.GET)
	public String showRegister() {
		return "user-register"; // 
	}

	@PostMapping("/register")
	public String registerhome(MemberVO vo, Model model) {
		memberService.addrMembers(vo);
		return "redirect:/user-login";
	}
	
	@RequestMapping(value={"/user-login","/myapp/user-login"}, method = RequestMethod.GET)
	public String showLogin() {
		return "user-login"; // userLogin.jsp
	}

	@GetMapping("/user-logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/user-login";
	}

}
